package com.jay.router.groovy

//实现参数配置: 1.定义参数类，限定参数类型
class RouterExtension {
    String wikiDir
}